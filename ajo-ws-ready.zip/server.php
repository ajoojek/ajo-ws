<?php
require 'vendor/autoload.php';
echo "Ajo WebSocket Server aktif!";
